// Recebe mensagem do content script e fecha a aba
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === 'WA_CLOSE_TAB' && sender.tab?.id) {
    chrome.tabs.remove(sender.tab.id)
  }
})
