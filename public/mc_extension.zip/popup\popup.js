'use strict'

// ── Labels legíveis por key ───────────────────────────────────────────────────
const LABELS = {
  agenda:          '0051 Agenda',
  aniversariantes: '0001 Aniversariantes',
  comissoes:       '0123 Comissões',
  caixa:           '0281 Caixa',
  tabela:          '0033 Tabela de Preços',
  faturamento_real:'0088 Faturamento Real',
}

// ── Inicialização ─────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const hoje = new Date()
  const primeiroDia = new Date(hoje.getFullYear(), hoje.getMonth(), 1)

  document.getElementById('inicio').value = toISO(primeiroDia)
  document.getElementById('fim').value    = toISO(hoje)

  // Restaura último ambiente escolhido
  chrome.storage.sync.get(['mcUrl'], ({ mcUrl }) => {
    if (mcUrl) {
      const radios = document.querySelectorAll('input[name="env"]')
      radios.forEach(r => { r.checked = r.value === mcUrl })
    }
  })

  document.getElementById('btnExecutar').addEventListener('click', onExecutar)
})

// ── Clique em Executar ────────────────────────────────────────────────────────
async function onExecutar() {
  const inicio = document.getElementById('inicio').value
  const fim    = document.getElementById('fim').value

  if (!inicio || !fim) return alert('Preencha o período.')

  const checkboxes = document.querySelectorAll('.checkboxes input[type="checkbox"]:checked')
  if (checkboxes.length === 0) return alert('Selecione ao menos um relatório.')

  const relatorios = Array.from(checkboxes).map(cb => ({
    key:    cb.dataset.key,
    codigo: cb.dataset.codigo,
  }))

  const mcUrl = document.querySelector('input[name="env"]:checked').value

  // Salva preferência
  chrome.storage.sync.set({ mcUrl })

  // Bloqueia botão
  const btn = document.getElementById('btnExecutar')
  btn.disabled = true
  btn.textContent = 'Executando…'

  // Monta status inicial
  const statusArea = document.getElementById('statusArea')
  statusArea.classList.remove('hidden')
  statusArea.innerHTML = ''
  renderStatusRows(relatorios)

  // Conecta com o background para receber atualizações
  const port = chrome.runtime.connect({ name: 'mc_extension' })
  port.onMessage.addListener(msg => handleStatus(msg, relatorios))
  port.onDisconnect.addListener(() => {
    btn.disabled = false
    btn.textContent = 'Executar'
  })

  // Inicia importação
  chrome.runtime.sendMessage({ action: 'startImport', relatorios, inicio, fim, mcUrl })
}

// ── Status ────────────────────────────────────────────────────────────────────
function renderStatusRows(relatorios) {
  const statusArea = document.getElementById('statusArea')

  // Cabeçalho AVEC
  addMsg('⬇ Baixando do AVEC…')

  relatorios.forEach(rel => {
    const row = document.createElement('div')
    row.className = 'status-row loading'
    row.id = `row-extract-${rel.key}`
    row.innerHTML = `<span class="icon">⏳</span> ${LABELS[rel.key]}`
    statusArea.appendChild(row)
  })
}

function handleStatus(msg, relatorios) {
  const statusArea = document.getElementById('statusArea')

  if (msg.phase === 'extract') {
    const row = document.getElementById(`row-extract-${msg.key}`)
    if (!row) return
    if (msg.state === 'done') {
      row.className = 'status-row done'
      row.innerHTML = `<span class="icon">✅</span> ${LABELS[msg.key]}`
    } else if (msg.state === 'error') {
      row.className = 'status-row error'
      row.innerHTML = `<span class="icon">❌</span> ${LABELS[msg.key]} — ${msg.error ?? ''}`
    }
  }

  if (msg.phase === 'upload' && msg.state === 'opening') {
    addMsg('⬆ Importando no mc_control…')
    relatorios.forEach(rel => {
      // Só adiciona linha de upload se a extração foi bem-sucedida
      const extractRow = document.getElementById(`row-extract-${rel.key}`)
      if (!extractRow?.classList.contains('done')) return

      const row = document.createElement('div')
      row.className = 'status-row loading'
      row.id = `row-upload-${rel.key}`
      row.innerHTML = `<span class="icon">⏳</span> ${LABELS[rel.key]}`
      statusArea.appendChild(row)
    })
  }

  if (msg.phase === 'upload' && msg.key) {
    const row = document.getElementById(`row-upload-${msg.key}`)
    if (!row) return
    if (msg.state === 'done') {
      row.className = 'status-row done'
      row.innerHTML = `<span class="icon">✅</span> ${LABELS[msg.key]}`
    } else if (msg.state === 'error') {
      row.className = 'status-row error'
      row.innerHTML = `<span class="icon">❌</span> ${LABELS[msg.key]} — ${msg.error ?? ''}`
    }
  }

  if (msg.phase === 'complete') {
    const done = document.createElement('div')
    done.className = 'status-complete'
    done.textContent = '✓ Importação concluída'
    statusArea.appendChild(done)

    document.getElementById('btnExecutar').disabled = false
    document.getElementById('btnExecutar').textContent = 'Executar'
  }

  if (msg.phase === 'error') {
    addMsg(`❌ Erro: ${msg.error}`)
    document.getElementById('btnExecutar').disabled = false
    document.getElementById('btnExecutar').textContent = 'Executar'
  }
}

function addMsg(text) {
  const el = document.createElement('div')
  el.className = 'status-msg'
  el.textContent = text
  document.getElementById('statusArea').appendChild(el)
}

// ── Utils ─────────────────────────────────────────────────────────────────────
function toISO(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}
