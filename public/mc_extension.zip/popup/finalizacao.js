'use strict'

// ── Finalização de agendamento ────────────────────────────────────────────────
// Monta a mensagem de confirmação e cola no chat aberto do WhatsApp Web, SEM enviar.

const CHAVE_PIX = 'meusciliossaojose@gmail.com'
const FAVORECIDO = 'G&G Company'
const PERCENTUAL_GARANTIA = 0.3
const MC_URL_PADRAO = 'https://mc-control.vercel.app'

// Valor na mensagem: inteiro sem centavos ("R$ 348"), senão "R$ 86,40"
const fmtValorMsg = n => `R$ ${Number.isInteger(n) ? n.toLocaleString('pt-BR') : fmtMoeda(n)}`

// "hoje"/"amanhã" ao lado da data, como a equipe escreve
function relativoDia(data) {
  const [dd, mm, yyyy] = data.split('/').map(Number)
  const alvo = new Date(yyyy, mm - 1, dd)
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0)
  const dias = Math.round((alvo - hoje) / 86400000)
  return dias === 0 ? ' hoje' : dias === 1 ? ' amanhã' : ''
}

const chaveOrdem = it => { const [dd, mm, yyyy] = it.data.split('/'); return `${yyyy}${mm}${dd}${it.hora}` }

// itens: [{ data, hora, servico, valor, desconto }] — desconto 0 = sem desconto
function montarMensagem({ nome, itens, garantia }) {
  const ordenados = [...itens].sort((a, b) => chaveOrdem(a).localeCompare(chaveOrdem(b)))
  const porDia = new Map()
  for (const it of ordenados) {
    if (!porDia.has(it.data)) porDia.set(it.data, [])
    porDia.get(it.data).push(it)
  }
  // Mesmo dia: "às 09h Esmaltação em gel + aplicação efeito foxy plus"
  const linhaDia = (data, its) =>
    `*${data}${relativoDia(data)}, às ${its[0].hora} para ${its.map(i => i.servico).join(' + ')}*`

  const dias = [...porDia]
  const agendamento = dias.length === 1
    ? [`${nome}, seu momento de autocuidado ficou agendado para o dia ${linhaDia(...dias[0])} 🥰`]
    : [
        `${nome}, seus momentos de autocuidado ficaram agendados para os dias: 🥰`,
        ...dias.map(([data, its]) => `• ${linhaDia(data, its)}`),
      ]

  const real = itens.reduce((s, i) => s + i.valor, 0)
  const cobrado = itens.reduce((s, i) => s + (i.desconto || i.valor), 0)
  const valorTotal = cobrado < real
    ? `Valor total: ~${fmtValorMsg(real)}~ por ${fmtValorMsg(cobrado)}`
    : `Valor total: ${fmtValorMsg(cobrado)}`

  return [
    '*Studio Meus Cílios :*',
    '*Arrasoou maravilhosa!*',
    '',
    ...agendamento,
    '',
    valorTotal,
    `Valor para garantia (30%): *${fmtValorMsg(garantia)}*`,
    `*Chave pix:* ${CHAVE_PIX}`,
    FAVORECIDO,
    '',
    '✨ *Política de Pagamento Antecipado* ✨',
    '*Cobramos 30% do valor do serviço na reserva.*',
    '',
    '*Cancelamentos ou remarcações* com até 24h de antecedência garantem a devolução integral.',
    '',
    '*Para cancelamentos tardios OU faltas*, o valor pago ficará como crédito para uso em até 30 dias. Após esse prazo, o crédito será perdido.',
    '',
    '',
    '📍 Nosso endereço: Rua Altamiro Di Bernardi 51, loja 04, bairro Campinas - São José/SC.',
    '(Próximo ao Camelão)',
    '',
    '',
    '⚠️ *Caso precise desmarcar seu horário, por gentileza, nos informe com, no mínimo, 24 horas de antecedência. Trabalhamos com agenda e isso é muito importante para nós e para a profissional que estará a sua espera!* 🥺',
  ].join('\n')
}

// ── Abas do popup ─────────────────────────────────────────────────────────────

function abrirAba(nome) {
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === nome))
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('active', p.id === `panel-${nome}`))
  chrome.storage.local.set({ abaPopup: nome })
}

// ── Máscaras ──────────────────────────────────────────────────────────────────

const soDigitos = s => s.replace(/\D/g, '')
const fmtMoeda = n => n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

// Dígitos entram pelos centavos: "35000" → "350,00"
function mascaraMoeda(v) {
  const d = soDigitos(v).replace(/^0+/, '')
  return d ? fmtMoeda(parseInt(d, 10) / 100) : ''
}
function valorMoeda(v) {
  const d = soDigitos(v)
  return d ? parseInt(d, 10) / 100 : 0
}

// "1211" → "12/11" (o ano entra ao sair do campo); aceita também "12112026"
function mascaraData(v) {
  const d = soDigitos(v).slice(0, 8)
  if (d.length <= 2) return d
  if (d.length <= 4) return `${d.slice(0, 2)}/${d.slice(2)}`
  return `${d.slice(0, 2)}/${d.slice(2, 4)}/${d.slice(4)}`
}
function completarData(v) {
  const d = soDigitos(v)
  if (d.length < 4) return v
  const ano = d.length >= 8 ? d.slice(4, 8) : String(new Date().getFullYear())
  return `${d.slice(0, 2)}/${d.slice(2, 4)}/${ano}`
}
function dataValida(v) {
  const m = v.match(/^(\d{2})\/(\d{2})\/(\d{4})$/)
  if (!m) return false
  const [, dd, mm, yyyy] = m.map(Number)
  const dt = new Date(yyyy, mm - 1, dd)
  return dt.getDate() === dd && dt.getMonth() === mm - 1
}

// "1430" → "14h30"
function mascaraHora(v) {
  const d = soDigitos(v).slice(0, 4)
  return d.length <= 2 ? d : `${d.slice(0, 2)}h${d.slice(2)}`
}
function completarHora(v) {
  const d = soDigitos(v)
  if (!d) return ''
  if (d.length === 1) return `0${d}h00`
  if (d.length === 2) return `${d}h00`
  if (d.length === 3) return `0${d[0]}h${d.slice(1)}`
  return `${d.slice(0, 2)}h${d.slice(2, 4)}`
}
function horaValida(v) {
  const m = v.match(/^(\d{2})h(\d{2})$/)
  return !!m && +m[1] < 24 && +m[2] < 60
}

// ── WhatsApp ──────────────────────────────────────────────────────────────────

async function abaWhatsApp() {
  const [ativa] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (ativa?.url?.startsWith('https://web.whatsapp.com')) return ativa
  const abas = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  return abas[0] ?? null
}

// Nome do contato da conversa aberta (cabeçalho do chat)
async function nomeDoChat(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const el = document.querySelector('#main header span[dir="auto"]')
        return el?.textContent?.trim() ?? ''
      },
    })
    return r?.result ?? ''
  } catch {
    return ''
  }
}

function primeiroNome(nomeChat) {
  if (!nomeChat || /^[+\d\s()-]+$/.test(nomeChat)) return ''   // é telefone
  const p = nomeChat.split(/\s+/)[0].replace(/[^\p{L}'-]/gu, '')
  return p ? p[0].toUpperCase() + p.slice(1).toLowerCase() : ''
}

// Cola o texto no campo de mensagem do chat aberto (evento de colar preserva quebras e *negrito*)
async function colarNoChat(tabId, texto) {
  const [r] = await chrome.scripting.executeScript({
    target: { tabId },
    args: [texto],
    func: async (texto) => {
      const input =
        document.querySelector('footer div[contenteditable="true"]') ||
        document.querySelector('#main div[contenteditable="true"][data-tab="10"]')
      if (!input) return { ok: false, motivo: 'sem_chat' }

      input.focus()
      const dt = new DataTransfer()
      dt.setData('text/plain', texto)
      input.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }))

      await new Promise(res => setTimeout(res, 400))
      const primeira = texto.split('\n').find(l => l.trim()).replace(/\*/g, '').slice(0, 15)
      const colou = input.textContent.replace(/\*/g, '').includes(primeira)
      return colou ? { ok: true } : { ok: false, motivo: 'nao_colou' }
    },
  })
  return r?.result ?? { ok: false, motivo: 'erro' }
}

// ── Serviços (tabela de preços do AVEC, via mc_control) ───────────────────────

// "1. Aplicação - Cílios Efeito Aurea" → "Aplicação - Cílios Efeito Aurea"
const limparServico = nome => nome.replace(/^\s*\d+\s*[-.]\s*/, '').trim()
const norm = s => s.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase()

let servicos = []   // [{ nome, preco? }]

async function carregarServicos() {
  const { servicosCache = [], servicos: usados = [] } = {
    ...(await chrome.storage.local.get('servicosCache')),
    ...(await chrome.storage.sync.get('servicos')),
  }
  const montar = tabela => {
    const porNome = new Map()
    for (const s of tabela) {
      const nome = limparServico(s.nome)
      if (nome && !porNome.has(norm(nome))) porNome.set(norm(nome), { nome, preco: s.preco })
    }
    for (const nome of usados) if (!porNome.has(norm(nome))) porNome.set(norm(nome), { nome })
    servicos = [...porNome.values()]
  }
  montar(servicosCache)

  // Atualiza do mc_control (cache fica para quando estiver offline)
  try {
    const { mcUrl } = await chrome.storage.sync.get('mcUrl')
    const res = await fetch(`${mcUrl || MC_URL_PADRAO}/api/servicos`)
    if (res.ok) {
      const { servicos: tabela } = await res.json()
      chrome.storage.local.set({ servicosCache: tabela })
      montar(tabela)
    }
  } catch { /* usa o cache */ }
}

// Autocomplete: todas as palavras digitadas, em qualquer posição, sem acento
function iniciarAutocompleteServico(input, lista, onEscolher) {
  let ativo = 0, sugestoes = []

  function render() {
    const q = norm(input.value.trim())
    const termos = q.split(/\s+/).filter(Boolean)
    sugestoes = q
      ? servicos
          .filter(s => { const n = norm(s.nome); return n !== q && termos.every(t => n.includes(t)) })
          .sort((a, b) => Number(norm(b.nome).startsWith(q)) - Number(norm(a.nome).startsWith(q)))
          .slice(0, 8)
      : []
    ativo = 0
    lista.innerHTML = ''
    sugestoes.forEach((s, i) => {
      const li = document.createElement('li')
      li.className = i === ativo ? 'ativo' : ''
      li.innerHTML = `<span></span>${s.preco ? `<small>R$ ${fmtMoeda(s.preco)}</small>` : ''}`
      li.firstChild.textContent = s.nome
      li.addEventListener('mousedown', e => { e.preventDefault(); escolher(i) })
      lista.appendChild(li)
    })
    lista.classList.toggle('hidden', sugestoes.length === 0)
  }

  function marcar() {
    ;[...lista.children].forEach((li, i) => li.classList.toggle('ativo', i === ativo))
  }

  function escolher(i) {
    const s = sugestoes[i]
    if (!s) return
    input.value = s.nome
    lista.classList.add('hidden')
    onEscolher(s)
  }

  input.addEventListener('input', render)
  input.addEventListener('focus', render)
  input.addEventListener('blur', () => lista.classList.add('hidden'))
  input.addEventListener('keydown', e => {
    if (lista.classList.contains('hidden')) return
    if (e.key === 'ArrowDown') { e.preventDefault(); ativo = Math.min(ativo + 1, sugestoes.length - 1); marcar() }
    else if (e.key === 'ArrowUp') { e.preventDefault(); ativo = Math.max(ativo - 1, 0); marcar() }
    else if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); escolher(ativo) }
    else if (e.key === 'Escape') lista.classList.add('hidden')
  })
}

// ── Formulário ────────────────────────────────────────────────────────────────

const $ = id => document.getElementById(id)
let garantiaManual = false
let chatAtual = ''

function status(msg, tipo = '') {
  const el = $('fStatus')
  el.textContent = msg
  el.className = `status-msg ${tipo}`
}

const cartoes = () => [...$('fItens').querySelectorAll('.item')]
const q = (card, cls) => card.querySelector(`.${cls}`)

function lerItens() {
  return cartoes().map(c => ({
    data: q(c, 'i-data').value, hora: q(c, 'i-hora').value, servico: q(c, 'i-servico').value,
    valor: q(c, 'i-valor').value, desconto: q(c, 'i-desconto').value,
  }))
}

function salvarRascunho() {
  chrome.storage.local.set({
    finalizacaoRascunho: {
      chat: chatAtual, nome: $('fNome').value, itens: lerItens(),
      garantia: $('fGarantia').value, garantiaManual,
    },
  })
}

// Total real (tabela) e cobrado (com desconto, quando houver)
function totais() {
  let real = 0, cobrado = 0
  for (const it of lerItens()) {
    const v = valorMoeda(it.valor), d = valorMoeda(it.desconto)
    real += v
    cobrado += d && d < v ? d : v
  }
  return { real, cobrado }
}

function atualizarTotais() {
  const { real, cobrado } = totais()
  $('fTotal').innerHTML = cobrado < real
    ? `<s>R$ ${fmtMoeda(real)}</s>R$ ${fmtMoeda(cobrado)}`
    : `R$ ${fmtMoeda(cobrado)}`
  if (!garantiaManual) {
    $('fGarantia').value = cobrado ? fmtMoeda(Math.round(cobrado * PERCENTUAL_GARANTIA * 100) / 100) : ''
  }
}

function numerar() {
  cartoes().forEach((c, i) => { q(c, 'item-n').textContent = `Serviço ${i + 1}` })
}

function adicionarItem(dados = {}) {
  const card = $('tplItem').content.firstElementChild.cloneNode(true)
  const fData = q(card, 'i-data'), fHora = q(card, 'i-hora'), fServico = q(card, 'i-servico')
  const fValor = q(card, 'i-valor'), fDesc = q(card, 'i-desconto'), picker = q(card, 'i-picker')

  fData.value = dados.data ?? ''
  fHora.value = dados.hora ?? ''
  fServico.value = dados.servico ?? ''
  fValor.value = dados.valor ?? ''
  fDesc.value = dados.desconto ?? ''

  fData.addEventListener('input', () => {
    fData.value = mascaraData(fData.value)
    if (soDigitos(fData.value).length === 4) fHora.focus()   // dd/mm digitado → ano no blur
  })
  fData.addEventListener('blur', () => { fData.value = completarData(fData.value); salvarRascunho() })

  // Calendário opcional
  q(card, 'i-cal').addEventListener('click', () => {
    if (dataValida(fData.value)) {
      const [dd, mm, yyyy] = fData.value.split('/')
      picker.value = `${yyyy}-${mm}-${dd}`
    }
    try { picker.showPicker() } catch { picker.click() }
  })
  picker.addEventListener('change', e => {
    const [yyyy, mm, dd] = e.target.value.split('-')
    if (yyyy) { fData.value = `${dd}/${mm}/${yyyy}`; salvarRascunho(); fHora.focus() }
  })

  fHora.addEventListener('input', () => {
    fHora.value = mascaraHora(fHora.value)
    if (soDigitos(fHora.value).length === 4) fServico.focus()
  })
  fHora.addEventListener('blur', () => { fHora.value = completarHora(fHora.value); salvarRascunho() })

  for (const f of [fValor, fDesc]) {
    f.addEventListener('input', () => { f.value = mascaraMoeda(f.value); atualizarTotais(); salvarRascunho() })
  }
  fServico.addEventListener('input', salvarRascunho)

  // Escolher um serviço da tabela já preenche o valor com o preço
  iniciarAutocompleteServico(fServico, q(card, 'ac-lista'), s => {
    if (s.preco) { fValor.value = fmtMoeda(s.preco); atualizarTotais() }
    salvarRascunho()
    fDesc.focus()
  })

  q(card, 'item-rm').addEventListener('click', () => {
    card.remove(); numerar(); atualizarTotais(); salvarRascunho()
  })

  $('fItens').appendChild(card)
  numerar()
  return card
}

async function iniciarFinalizacao() {
  const fGarantia = $('fGarantia')

  fGarantia.addEventListener('input', () => {
    fGarantia.value = mascaraMoeda(fGarantia.value)
    garantiaManual = fGarantia.value !== ''   // apagou → volta a calcular sozinho
    if (!garantiaManual) atualizarTotais()
    salvarRascunho()
  })
  $('fNome').addEventListener('input', salvarRascunho)

  // Novo serviço já vem com a data do anterior (mesmo dia é o mais comum)
  $('fAddItem').addEventListener('click', () => {
    const ultimo = cartoes().at(-1)
    const card = adicionarItem({ data: ultimo ? q(ultimo, 'i-data').value : '' })
    q(card, q(card, 'i-data').value ? 'i-hora' : 'i-data').focus()
    salvarRascunho()
  })
  $('btnPreencher').addEventListener('click', preencher)

  carregarServicos()

  // Conversa aberta → nome; rascunho só volta se for da mesma conversa
  const aba = await abaWhatsApp()
  chatAtual = aba ? await nomeDoChat(aba.id) : ''
  const { finalizacaoRascunho: r } = await chrome.storage.local.get('finalizacaoRascunho')
  if (r && r.chat === chatAtual && Array.isArray(r.itens) && r.itens.length) {
    $('fNome').value = r.nome
    r.itens.forEach(it => adicionarItem(it))
    garantiaManual = !!r.garantiaManual
    fGarantia.value = r.garantia
  } else {
    $('fNome').value = primeiroNome(chatAtual)
    adicionarItem()
  }
  atualizarTotais()
  if (!aba) status('Abra o WhatsApp Web numa aba para colar a mensagem.', 'aviso')
  ;($('fNome').value ? q(cartoes()[0], 'i-data') : $('fNome')).focus()
}

async function preencher() {
  const nome = $('fNome').value.trim()
  if (!nome) return status('Preencha o nome.', 'erro')

  const lista = cartoes()
  const itens = []
  for (const [i, c] of lista.entries()) {
    const fData = q(c, 'i-data'), fHora = q(c, 'i-hora')
    fData.value = completarData(fData.value)
    fHora.value = completarHora(fHora.value)
    const it = {
      data: fData.value, hora: fHora.value, servico: q(c, 'i-servico').value.trim(),
      valor: valorMoeda(q(c, 'i-valor').value), desconto: valorMoeda(q(c, 'i-desconto').value),
    }
    const n = lista.length > 1 ? ` (serviço ${i + 1})` : ''
    if (!dataValida(it.data)) return status(`Data inválida${n} (dd/mm/aaaa).`, 'erro')
    if (!horaValida(it.hora)) return status(`Horário inválido${n} (ex: 14h30).`, 'erro')
    if (!it.servico) return status(`Preencha o serviço${n}.`, 'erro')
    if (!it.valor) return status(`Preencha o valor${n}.`, 'erro')
    if (it.desconto >= it.valor) it.desconto = 0   // "desconto" igual/maior que o valor = sem desconto
    itens.push(it)
  }
  const garantia = valorMoeda($('fGarantia').value)
  if (!garantia) return status('Preencha o valor da garantia.', 'erro')

  const texto = montarMensagem({ nome, itens, garantia })

  // Lembra os serviços para as próximas
  const { servicos: usados = [] } = await chrome.storage.sync.get('servicos')
  chrome.storage.sync.set({ servicos: [...new Set([...itens.map(i => i.servico), ...usados])].slice(0, 20) })

  const aba = await abaWhatsApp()
  const r = aba ? await colarNoChat(aba.id, texto) : { ok: false, motivo: 'sem_aba' }

  if (r.ok) {
    chrome.storage.local.remove('finalizacaoRascunho')
    status('✓ Mensagem colada no chat. Revise e envie.', 'ok')
    if (aba) chrome.tabs.update(aba.id, { active: true })
    return
  }

  // Não conseguiu colar: deixa na área de transferência
  await navigator.clipboard.writeText(texto)
  const motivo = {
    sem_aba: 'WhatsApp Web não está aberto.',
    sem_chat: 'Nenhuma conversa aberta no WhatsApp.',
  }[r.motivo] ?? 'Não consegui colar no chat.'
  status(`${motivo} Mensagem copiada — cole com Ctrl+V.`, 'aviso')
}

document.addEventListener('DOMContentLoaded', async () => {
  document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => abrirAba(t.dataset.tab)))
  const { abaPopup } = await chrome.storage.local.get('abaPopup')
  abrirAba(abaPopup === 'avec' ? 'avec' : 'finalizacao')
  iniciarFinalizacao()
})
