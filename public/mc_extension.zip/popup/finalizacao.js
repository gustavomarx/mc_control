'use strict'

// ── Finalização de agendamento ────────────────────────────────────────────────
// Monta a mensagem de confirmação e cola no chat aberto do WhatsApp Web, SEM enviar.

const CHAVE_PIX = 'meusciliossaojose@gmail.com'
const FAVORECIDO = 'G&G Company'
const PERCENTUAL_GARANTIA = 0.3
const MC_URL_PADRAO = 'https://mc-control.vercel.app'

function montarMensagem({ nome, data, hora, servico, total, garantia }) {
  return [
    '*Studio Meus Cílios :*',
    '*Arrasoou maravilhosa!*',
    '',
    `${nome}, seu momento de autocuidado ficou agendado para o dia *${data}, às ${hora} para ${servico}* 🥰`,
    '',
    `Valor total: R$ ${total}`,
    `Valor para garantia (30%): R$ *${garantia}*`,
    `*Chave pix:* ${CHAVE_PIX}`,
    FAVORECIDO,
    '',
    '✨ *Política de Pagamento Antecipado* ✨',
    '*Cobramos 30% do valor do serviço na reserva.*',
    '',
    '*Cancelamentos ou remarcações* com até 24h de antecedência garantem a devolução integral.',
    '',
    '*Para cancelamentos tardios OU faltas*, o valor pago ficará como crédito para uso em até 30 dias. Após esse prazo, o crédito será perdido.',
    '',
    '',
    '📍 Nosso endereço: Rua Altamiro Di Bernardi 51, loja 04, bairro Campinas - São José/SC.',
    '(Próximo ao Camelão)',
    '',
    '',
    '⚠️ *Caso precise desmarcar seu horário, por gentileza, nos informe com, no mínimo, 24 horas de antecedência. Trabalhamos com agenda e isso é muito importante para nós e para a profissional que estará a sua espera!* 🥺',
  ].join('\n')
}

// ── Abas do popup ─────────────────────────────────────────────────────────────

function abrirAba(nome) {
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === nome))
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('active', p.id === `panel-${nome}`))
  chrome.storage.local.set({ abaPopup: nome })
}

// ── Máscaras ──────────────────────────────────────────────────────────────────

const soDigitos = s => s.replace(/\D/g, '')
const fmtMoeda = n => n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

// Dígitos entram pelos centavos: "35000" → "350,00"
function mascaraMoeda(v) {
  const d = soDigitos(v).replace(/^0+/, '')
  return d ? fmtMoeda(parseInt(d, 10) / 100) : ''
}
function valorMoeda(v) {
  const d = soDigitos(v)
  return d ? parseInt(d, 10) / 100 : 0
}

// "1211" → "12/11" (o ano entra ao sair do campo); aceita também "12112026"
function mascaraData(v) {
  const d = soDigitos(v).slice(0, 8)
  if (d.length <= 2) return d
  if (d.length <= 4) return `${d.slice(0, 2)}/${d.slice(2)}`
  return `${d.slice(0, 2)}/${d.slice(2, 4)}/${d.slice(4)}`
}
function completarData(v) {
  const d = soDigitos(v)
  if (d.length < 4) return v
  const ano = d.length >= 8 ? d.slice(4, 8) : String(new Date().getFullYear())
  return `${d.slice(0, 2)}/${d.slice(2, 4)}/${ano}`
}
function dataValida(v) {
  const m = v.match(/^(\d{2})\/(\d{2})\/(\d{4})$/)
  if (!m) return false
  const [, dd, mm, yyyy] = m.map(Number)
  const dt = new Date(yyyy, mm - 1, dd)
  return dt.getDate() === dd && dt.getMonth() === mm - 1
}

// "1430" → "14h30"
function mascaraHora(v) {
  const d = soDigitos(v).slice(0, 4)
  return d.length <= 2 ? d : `${d.slice(0, 2)}h${d.slice(2)}`
}
function completarHora(v) {
  const d = soDigitos(v)
  if (!d) return ''
  if (d.length === 1) return `0${d}h00`
  if (d.length === 2) return `${d}h00`
  if (d.length === 3) return `0${d[0]}h${d.slice(1)}`
  return `${d.slice(0, 2)}h${d.slice(2, 4)}`
}
function horaValida(v) {
  const m = v.match(/^(\d{2})h(\d{2})$/)
  return !!m && +m[1] < 24 && +m[2] < 60
}

// ── WhatsApp ──────────────────────────────────────────────────────────────────

async function abaWhatsApp() {
  const [ativa] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (ativa?.url?.startsWith('https://web.whatsapp.com')) return ativa
  const abas = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  return abas[0] ?? null
}

// Nome do contato da conversa aberta (cabeçalho do chat)
async function nomeDoChat(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const el = document.querySelector('#main header span[dir="auto"]')
        return el?.textContent?.trim() ?? ''
      },
    })
    return r?.result ?? ''
  } catch {
    return ''
  }
}

function primeiroNome(nomeChat) {
  if (!nomeChat || /^[+\d\s()-]+$/.test(nomeChat)) return ''   // é telefone
  const p = nomeChat.split(/\s+/)[0].replace(/[^\p{L}'-]/gu, '')
  return p ? p[0].toUpperCase() + p.slice(1).toLowerCase() : ''
}

// Cola o texto no campo de mensagem do chat aberto (evento de colar preserva quebras e *negrito*)
async function colarNoChat(tabId, texto) {
  const [r] = await chrome.scripting.executeScript({
    target: { tabId },
    args: [texto],
    func: async (texto) => {
      const input =
        document.querySelector('footer div[contenteditable="true"]') ||
        document.querySelector('#main div[contenteditable="true"][data-tab="10"]')
      if (!input) return { ok: false, motivo: 'sem_chat' }

      input.focus()
      const dt = new DataTransfer()
      dt.setData('text/plain', texto)
      input.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }))

      await new Promise(res => setTimeout(res, 400))
      const primeira = texto.split('\n').find(l => l.trim()).replace(/\*/g, '').slice(0, 15)
      const colou = input.textContent.replace(/\*/g, '').includes(primeira)
      return colou ? { ok: true } : { ok: false, motivo: 'nao_colou' }
    },
  })
  return r?.result ?? { ok: false, motivo: 'erro' }
}

// ── Serviços (tabela de preços do AVEC, via mc_control) ───────────────────────

// "1. Aplicação - Cílios Efeito Aurea" → "Aplicação - Cílios Efeito Aurea"
const limparServico = nome => nome.replace(/^\s*\d+\s*[-.]\s*/, '').trim()
const norm = s => s.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase()

let servicos = []   // [{ nome, preco? }]

async function carregarServicos() {
  const { servicosCache = [], servicos: usados = [] } = {
    ...(await chrome.storage.local.get('servicosCache')),
    ...(await chrome.storage.sync.get('servicos')),
  }
  const montar = tabela => {
    const porNome = new Map()
    for (const s of tabela) {
      const nome = limparServico(s.nome)
      if (nome && !porNome.has(norm(nome))) porNome.set(norm(nome), { nome, preco: s.preco })
    }
    for (const nome of usados) if (!porNome.has(norm(nome))) porNome.set(norm(nome), { nome })
    servicos = [...porNome.values()]
  }
  montar(servicosCache)

  // Atualiza do mc_control (cache fica para quando estiver offline)
  try {
    const { mcUrl } = await chrome.storage.sync.get('mcUrl')
    const res = await fetch(`${mcUrl || MC_URL_PADRAO}/api/servicos`)
    if (res.ok) {
      const { servicos: tabela } = await res.json()
      chrome.storage.local.set({ servicosCache: tabela })
      montar(tabela)
    }
  } catch { /* usa o cache */ }
}

// Autocomplete: todas as palavras digitadas, em qualquer posição, sem acento
function iniciarAutocompleteServico(onEscolher) {
  const input = $('fServico'), lista = $('fServicoLista')
  let ativo = 0, sugestoes = []

  function render() {
    const q = norm(input.value.trim())
    const termos = q.split(/\s+/).filter(Boolean)
    sugestoes = q
      ? servicos
          .filter(s => { const n = norm(s.nome); return n !== q && termos.every(t => n.includes(t)) })
          .sort((a, b) => Number(norm(b.nome).startsWith(q)) - Number(norm(a.nome).startsWith(q)))
          .slice(0, 8)
      : []
    ativo = 0
    lista.innerHTML = ''
    sugestoes.forEach((s, i) => {
      const li = document.createElement('li')
      li.className = i === ativo ? 'ativo' : ''
      li.innerHTML = `<span></span>${s.preco ? `<small>R$ ${fmtMoeda(s.preco)}</small>` : ''}`
      li.firstChild.textContent = s.nome
      li.addEventListener('mousedown', e => { e.preventDefault(); escolher(i) })
      lista.appendChild(li)
    })
    lista.classList.toggle('hidden', sugestoes.length === 0)
  }

  function marcar() {
    ;[...lista.children].forEach((li, i) => li.classList.toggle('ativo', i === ativo))
  }

  function escolher(i) {
    const s = sugestoes[i]
    if (!s) return
    input.value = s.nome
    lista.classList.add('hidden')
    onEscolher(s)
  }

  input.addEventListener('input', render)
  input.addEventListener('focus', render)
  input.addEventListener('blur', () => lista.classList.add('hidden'))
  input.addEventListener('keydown', e => {
    if (lista.classList.contains('hidden')) return
    if (e.key === 'ArrowDown') { e.preventDefault(); ativo = Math.min(ativo + 1, sugestoes.length - 1); marcar() }
    else if (e.key === 'ArrowUp') { e.preventDefault(); ativo = Math.max(ativo - 1, 0); marcar() }
    else if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); escolher(ativo) }
    else if (e.key === 'Escape') lista.classList.add('hidden')
  })
}

// ── Formulário ────────────────────────────────────────────────────────────────

const $ = id => document.getElementById(id)
let garantiaManual = false
let chatAtual = ''

function status(msg, tipo = '') {
  const el = $('fStatus')
  el.textContent = msg
  el.className = `status-msg ${tipo}`
}

function salvarRascunho() {
  chrome.storage.local.set({
    finalizacaoRascunho: {
      chat: chatAtual,
      nome: $('fNome').value, data: $('fData').value, hora: $('fHora').value,
      servico: $('fServico').value, total: $('fTotal').value, garantia: $('fGarantia').value,
      garantiaManual,
    },
  })
}

function recalcularGarantia() {
  if (garantiaManual) return
  const total = valorMoeda($('fTotal').value)
  $('fGarantia').value = total ? fmtMoeda(Math.round(total * PERCENTUAL_GARANTIA * 100) / 100) : ''
}

async function iniciarFinalizacao() {
  const fData = $('fData'), fHora = $('fHora'), fTotal = $('fTotal'), fGarantia = $('fGarantia')

  fData.addEventListener('input', () => {
    fData.value = mascaraData(fData.value)
    if (soDigitos(fData.value).length === 4) fHora.focus()   // dd/mm digitado → ano no blur
  })
  fData.addEventListener('blur', () => { fData.value = completarData(fData.value); salvarRascunho() })

  // Calendário opcional
  $('fDataCal').addEventListener('click', () => {
    const p = $('fDataPicker')
    if (dataValida(fData.value)) {
      const [dd, mm, yyyy] = fData.value.split('/')
      p.value = `${yyyy}-${mm}-${dd}`
    }
    try { p.showPicker() } catch { p.click() }
  })
  $('fDataPicker').addEventListener('change', e => {
    const [yyyy, mm, dd] = e.target.value.split('-')
    if (yyyy) { fData.value = `${dd}/${mm}/${yyyy}`; salvarRascunho(); fHora.focus() }
  })

  fHora.addEventListener('input', () => {
    fHora.value = mascaraHora(fHora.value)
    if (soDigitos(fHora.value).length === 4) $('fServico').focus()
  })
  fHora.addEventListener('blur', () => { fHora.value = completarHora(fHora.value); salvarRascunho() })

  fTotal.addEventListener('input', () => { fTotal.value = mascaraMoeda(fTotal.value); recalcularGarantia() })
  fGarantia.addEventListener('input', () => {
    fGarantia.value = mascaraMoeda(fGarantia.value)
    garantiaManual = fGarantia.value !== ''   // apagou → volta a calcular sozinho
    if (!garantiaManual) recalcularGarantia()
  })

  for (const id of ['fNome', 'fServico', 'fTotal', 'fGarantia']) $(id).addEventListener('input', salvarRascunho)
  $('btnPreencher').addEventListener('click', preencher)

  // Serviços: escolher um da tabela já preenche o valor total com o preço
  carregarServicos()
  iniciarAutocompleteServico(s => {
    if (s.preco) {
      fTotal.value = fmtMoeda(s.preco)
      garantiaManual = false
      recalcularGarantia()
    }
    salvarRascunho()
    fTotal.focus()
  })

  // Conversa aberta → nome; rascunho só volta se for da mesma conversa
  const aba = await abaWhatsApp()
  chatAtual = aba ? await nomeDoChat(aba.id) : ''
  const { finalizacaoRascunho: r } = await chrome.storage.local.get('finalizacaoRascunho')
  if (r && r.chat === chatAtual) {
    $('fNome').value = r.nome; fData.value = r.data; fHora.value = r.hora
    $('fServico').value = r.servico; fTotal.value = r.total; fGarantia.value = r.garantia
    garantiaManual = !!r.garantiaManual
  } else {
    $('fNome').value = primeiroNome(chatAtual)
  }
  if (!aba) status('Abra o WhatsApp Web numa aba para colar a mensagem.', 'aviso')
  ;($('fNome').value ? fData : $('fNome')).focus()
}

async function preencher() {
  const fData = $('fData'), fHora = $('fHora')
  fData.value = completarData(fData.value)
  fHora.value = completarHora(fHora.value)

  const campos = {
    nome: $('fNome').value.trim(),
    data: fData.value,
    hora: fHora.value,
    servico: $('fServico').value.trim(),
    total: $('fTotal').value,
    garantia: $('fGarantia').value,
  }
  if (!campos.nome) return status('Preencha o nome.', 'erro')
  if (!dataValida(campos.data)) return status('Data inválida (dd/mm/aaaa).', 'erro')
  if (!horaValida(campos.hora)) return status('Horário inválido (ex: 14h30).', 'erro')
  if (!campos.servico) return status('Preencha o serviço.', 'erro')
  if (!valorMoeda(campos.total)) return status('Preencha o valor total.', 'erro')
  if (!valorMoeda(campos.garantia)) return status('Preencha o valor da garantia.', 'erro')

  const texto = montarMensagem(campos)

  // Lembra o serviço para as próximas
  const { servicos: usados = [] } = await chrome.storage.sync.get('servicos')
  chrome.storage.sync.set({ servicos: [campos.servico, ...usados.filter(s => s !== campos.servico)].slice(0, 20) })

  const aba = await abaWhatsApp()
  const r = aba ? await colarNoChat(aba.id, texto) : { ok: false, motivo: 'sem_aba' }

  if (r.ok) {
    chrome.storage.local.remove('finalizacaoRascunho')
    status('✓ Mensagem colada no chat. Revise e envie.', 'ok')
    if (aba) chrome.tabs.update(aba.id, { active: true })
    return
  }

  // Não conseguiu colar: deixa na área de transferência
  await navigator.clipboard.writeText(texto)
  const motivo = {
    sem_aba: 'WhatsApp Web não está aberto.',
    sem_chat: 'Nenhuma conversa aberta no WhatsApp.',
  }[r.motivo] ?? 'Não consegui colar no chat.'
  status(`${motivo} Mensagem copiada — cole com Ctrl+V.`, 'aviso')
}

document.addEventListener('DOMContentLoaded', async () => {
  document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => abrirAba(t.dataset.tab)))
  const { abaPopup } = await chrome.storage.local.get('abaPopup')
  abrirAba(abaPopup === 'avec' ? 'avec' : 'finalizacao')
  iniciarFinalizacao()
})
