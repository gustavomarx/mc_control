'use strict'

// ── WA Auto Sender ────────────────────────────────────────────────────────────
// Recebe mensagem do content_wa.js e fecha a aba do WhatsApp

// ── AVEC Importer — comunicação com popup e página ────────────────────────────
let popupPort = null
let mcTabId   = null  // aba do mc_control que iniciou a importação via botão injetado

chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'mc_extension') return
  popupPort = port
  port.onDisconnect.addListener(() => { popupPort = null })
})

function sendStatus(status) {
  if (popupPort) popupPort.postMessage(status)
  if (mcTabId)  chrome.tabs.sendMessage(mcTabId, { action: 'statusUpdate', ...status }).catch(() => {})
}

// ── Listener unificado ────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'WA_CLOSE_TAB' && sender.tab?.id) {
    chrome.tabs.remove(sender.tab.id)
    return
  }

  if (msg.action === 'startImport') {
    mcTabId = sender.tab?.id ?? null
    runImport(msg).catch(err => {
      sendStatus({ phase: 'error', error: err.message })
    })
    sendResponse({ ok: true })
  }
})

// ── Fluxo de importação AVEC ──────────────────────────────────────────────────

// Gera lista de meses fechados (1º ao último dia) dentro de um intervalo
function gerarMesesFechados(inicio, fim) {
  const meses = []
  let [y, m] = inicio.split('-').map(Number)
  const [fy, fm] = fim.split('-').map(Number)
  while (y < fy || (y === fy && m <= fm)) {
    const mm    = String(m).padStart(2, '0')
    const ultDia = new Date(y, m, 0).getDate()
    meses.push({
      inicio: `${y}-${mm}-01`,
      fim:    `${y}-${mm}-${String(ultDia).padStart(2, '0')}`,
    })
    if (++m > 12) { m = 1; y++ }
  }
  return meses
}

async function runImport({ relatorios, inicio, fim, mcUrl }) {
  const files = []

  // Expande comissoes em tarefas mensais; demais usam o período global
  const tasks = []
  for (const rel of relatorios) {
    if (rel.key === 'comissoes') {
      for (const mes of gerarMesesFechados(inicio, fim)) {
        const mesId = mes.inicio.slice(0, 7)              // "2026-03"
        tasks.push({ ...rel, statusKey: `comissoes_${mesId}`, taskInicio: mes.inicio, taskFim: mes.fim })
      }
    } else {
      tasks.push({ ...rel, statusKey: rel.key, taskInicio: inicio, taskFim: fim })
    }
  }

  // Fase 1: extração do AVEC
  for (const task of tasks) {
    const rel = task
    sendStatus({ phase: 'extract', key: task.statusKey, state: 'loading' })

    let tab
    try {
      tab = await chrome.tabs.create({
        url: `https://admin.avec.beauty/admin/relatorio/${rel.codigo}`,
        active: false,
      })

      await waitForTabLoad(tab.id)
      await sleep(800)

      // Injeta interceptor de URL.createObjectURL no contexto da página
      // (via scripting API — ignora CSP do AVEC, diferente de <script> inline)
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        func: () => {
          if (window.__mc_interceptor_active) return
          window.__mc_interceptor_active = true
          const _orig = URL.createObjectURL.bind(URL)
          URL.createObjectURL = function (obj) {
            const url = _orig(obj)
            if (obj instanceof Blob && obj.size > 500) {
              obj.arrayBuffer().then(buf => {
                window.postMessage(
                  { type: '__mc_excel_ready', bytes: Array.from(new Uint8Array(buf)) },
                  '*'
                )
              })
            }
            return url
          }
        },
      })

      const tabId    = tab.id
      const filename = `relatorio_${rel.codigo}_${Date.now()}.xlsx`

      // Race: caminho cliente (blob interceptado) vs caminho servidor (download HTTP)
      const fileData = await new Promise((resolve, reject) => {
        let settled    = false
        let blobLsn    = null
        let dlLsn      = null
        let timer      = null

        function settle(fn) {
          if (settled) return
          settled = true
          if (blobLsn) chrome.runtime.onMessage.removeListener(blobLsn)
          if (dlLsn)   chrome.downloads.onCreated.removeListener(dlLsn)
          if (timer)   clearTimeout(timer)
          fn()
        }

        timer = setTimeout(
          () => settle(() => reject(new Error('Timeout aguardando arquivo Excel'))),
          35_000
        )

        // Caminho A: geração client-side (DataTables Buttons cria Blob → URL.createObjectURL)
        // content_avec.js recebe via postMessage e repassa aqui via chrome.runtime.sendMessage
        blobLsn = (msg, sender) => {
          if (sender.tab?.id !== tabId || msg.action !== '__mc_blob_ready') return
          settle(() => resolve({ data: msg.data, filename }))
        }
        chrome.runtime.onMessage.addListener(blobLsn)

        // Caminho B: geração server-side (servidor retorna o arquivo como download HTTP)
        // chrome.downloads.onCreated captura a URL → content script re-faz o fetch com cookies
        dlLsn = (item) => {
          if (item.tabId !== tabId) return
          settle(() => {
            // Cancela o arquivo no disco (não precisamos dele)
            chrome.downloads.cancel(item.id).catch(() => {})
            chrome.downloads.erase({ id: item.id }).catch(() => {})
            // Re-faz o request via content script (tem as cookies da sessão AVEC)
            chrome.tabs.sendMessage(tabId, { action: 'fetchUrl', url: item.url, filename })
              .then(r => r?.ok ? resolve(r) : reject(new Error(r?.error ?? 'fetchUrl falhou')))
              .catch(reject)
          })
        }
        chrome.downloads.onCreated.addListener(dlLsn)

        // Seta datas via MAIN world — bypassa CSP do AVEC e tem acesso ao jQuery/datepicker
        await chrome.scripting.executeScript({
          target: { tabId },
          world: 'MAIN',
          args: [toDateBR(task.taskInicio), toDateBR(task.taskFim)],
          func: (inicio, fim) => {
            function setDate(name, value) {
              const el = document.querySelector('input[name="' + name + '"]')
              if (!el) return
              el.focus()
              el.value = value
              ;['input', 'change', 'keyup'].forEach(n =>
                el.dispatchEvent(new Event(n, { bubbles: true }))
              )
              try { window.jQuery(el).datepicker('update') } catch (e) {}
              try { window.$(el).datepicker('update') } catch (e) {}
              el.dispatchEvent(new Event('blur', { bubbles: true }))
            }
            setDate('inicio', inicio)
            setDate('fim', fim)
          },
        })
        await sleep(300)

        // Dispara a interação — listeners já estão registrados
        chrome.tabs.sendMessage(tabId, {
          action: 'extractReport',
          inicio: toDateBR(task.taskInicio),
          fim:    toDateBR(task.taskFim),
        }).then(r => {
          if (!r?.ok) settle(() => reject(new Error(r?.error ?? 'Falha na extração')))
        }).catch(err => settle(() => reject(err)))
      })

      files.push({ key: task.key, statusKey: task.statusKey, data: fileData.data, filename: fileData.filename, taskInicio: task.taskInicio, taskFim: task.taskFim })
      sendStatus({ phase: 'extract', key: task.statusKey, state: 'done' })
    } catch (err) {
      sendStatus({ phase: 'extract', key: task.statusKey, state: 'error', error: err.message })
    } finally {
      if (tab) await chrome.tabs.remove(tab.id).catch(() => {})
    }
  }

  if (files.length === 0) {
    sendStatus({ phase: 'error', error: 'Nenhum arquivo foi extraído do AVEC.' })
    return
  }

  // Fase 2: upload no mc_control
  sendStatus({ phase: 'upload', state: 'opening' })

  // Se a importação foi disparada da própria página do mc_control (mcTabId definido),
  // usa essa aba diretamente — bridge já está pronto, usuário já autenticado.
  // Só cria nova aba se veio do popup (mcTabId = null).
  let uploadTabId = mcTabId
  let newMcTab    = null

  if (!uploadTabId) {
    newMcTab    = await chrome.tabs.create({ url: `${mcUrl}/importacoes`, active: true })
    uploadTabId = newMcTab.id
    await waitForTabLoad(uploadTabId)
  }

  const bridgeReady = await waitForBridge(uploadTabId)
  if (!bridgeReady) {
    sendStatus({ phase: 'error', error: 'Bridge não encontrado na página de importações.' })
    return
  }

  for (const file of files) {
    sendStatus({ phase: 'upload', key: file.statusKey, state: 'loading' })
    try {
      // Injeta direto no main world — onde window.__mcImport existe (definido pelo React)
      // content_mc.js roda no isolated world e não tem acesso a esse window
      const [res] = await chrome.scripting.executeScript({
        target: { tabId: uploadTabId },
        world:  'MAIN',
        args:   [file.key, file.data, file.filename, file.taskInicio, file.taskFim],
        func: async (key, data, filename, inicio, fim) => {
          if (typeof window.__mcImport !== 'function')
            return { ok: false, error: 'Bridge __mcImport não encontrado' }
          try {
            const uint8 = new Uint8Array(data)
            const blob  = new Blob([uint8], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
            const f     = new File([blob], filename, { type: blob.type })
            await window.__mcImport(key, f, { inicio, fim })
            return { ok: true }
          } catch (err) {
            return { ok: false, error: err.message }
          }
        },
      })
      if (!res?.result?.ok) throw new Error(res?.result?.error ?? 'Falha no upload')
      sendStatus({ phase: 'upload', key: file.statusKey, state: 'done' })
    } catch (err) {
      sendStatus({ phase: 'upload', key: file.statusKey, state: 'error', error: err.message })
    }

    await sleep(800)
  }

  sendStatus({ phase: 'complete' })
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function waitForTabLoad(tabId) {
  return new Promise(resolve => {
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener)
        resolve()
      }
    }
    chrome.tabs.onUpdated.addListener(listener)
  })
}

async function waitForBridge(tabId, retries = 20) {
  for (let i = 0; i < retries; i++) {
    try {
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN', // __mcImport é definido no contexto da página, não no isolated world
        func: () => typeof window.__mcImport === 'function',
      })
      if (res.result) return true
    } catch {}
    await sleep(500)
  }
  return false
}

function toDateBR(isoDate) {
  const [y, m, d] = isoDate.split('-')
  return `${d}/${m}/${y}`
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms))
}
