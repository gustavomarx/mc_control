'use strict'

// ── Relay: page context → background (client-side blob path) ──────────────────
// Injected interceptor fires window.postMessage → content script relays to background
window.addEventListener('message', e => {
  if (e.source !== window || e.data?.type !== '__mc_excel_ready') return
  chrome.runtime.sendMessage({ action: '__mc_blob_ready', data: e.data.bytes })
})

// ── Listener principal ────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'extractReport') {
    clickReport(msg.inicio, msg.fim)
      .then(r => sendResponse(r))
      .catch(err => sendResponse({ ok: false, error: err.message }))
    return true
  }

  // Server-side path: background captured download URL, we re-fetch with cookies
  if (msg.action === 'fetchUrl') {
    fetch(msg.url, { credentials: 'include' })
      .then(r => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.arrayBuffer() })
      .then(buf => sendResponse({ ok: true, data: Array.from(new Uint8Array(buf)), filename: msg.filename }))
      .catch(err => sendResponse({ ok: false, error: err.message }))
    return true
  }
})

// ── Interação com a UI do AVEC ────────────────────────────────────────────────
async function clickReport(inicio, fim) {
  const inputInicio = document.querySelector('input[name="inicio"]')
  const inputFim    = document.querySelector('input[name="fim"]')
  if (!inputInicio || !inputFim) throw new Error('Campos de data não encontrados')

  setInputValue(inputInicio, inicio)
  setInputValue(inputFim, fim)

  // Aguarda o datepicker processar os novos valores antes de buscar
  await new Promise(r => setTimeout(r, 400))

  const buscarBtn = findBuscarButton()
  if (!buscarBtn) throw new Error('Botão Buscar não encontrado')
  buscarBtn.click()

  await waitForTable()

  const excelBtn = findExcelButton()
  if (!excelBtn) throw new Error('Botão Excel não encontrado')
  excelBtn.click()

  // Retorna imediatamente — background aguarda o arquivo via blob ou download
  return { ok: true }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function setInputValue(input, value) {
  const name = input.getAttribute('name') || ''

  // Injeta no contexto da página para acessar jQuery/datepicker plugin
  const script = document.createElement('script')
  script.textContent = `
    (function() {
      var el = document.querySelector('input[name="${name}"]');
      if (!el) return;
      el.focus();
      el.value = '${value}';
      try { $(el).datepicker('update', '${value}'); } catch(e) {}
      el.dispatchEvent(new Event('input',  { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur',   { bubbles: true }));
    })();
  `
  document.documentElement.appendChild(script)
  script.remove()
}

function findBuscarButton() {
  for (const sel of ['button[type="submit"]', '.btn-buscar', 'button.btn-primary', 'button.btn-success']) {
    const el = document.querySelector(sel)
    if (el) return el
  }
  return Array.from(document.querySelectorAll('button')).find(b =>
    b.textContent.trim().toLowerCase().includes('buscar')
  ) ?? null
}

function waitForTable(timeout = 30_000) {
  return new Promise((resolve, reject) => {
    const deadline = Date.now() + timeout
    function check() {
      const rows       = document.querySelectorAll('table tbody tr')
      const processing = document.querySelector('.dataTables_processing')
      const isEmpty    = document.querySelector('.dataTables_empty')
      const loaded = (rows.length > 0 && (!processing || processing.style.display === 'none')) || isEmpty != null
      if (loaded) return resolve()
      if (Date.now() > deadline) return reject(new Error('Timeout aguardando tabela carregar'))
      setTimeout(check, 600)
    }
    setTimeout(check, 1_200)
  })
}

function findExcelButton() {
  const byClass = document.querySelector('.buttons-excel, .dt-button.buttons-excel')
  if (byClass) return byClass
  return Array.from(document.querySelectorAll('button, a.dt-button')).find(el =>
    el.textContent.trim() === 'Excel'
  ) ?? null
}
