'use strict'

// ── Comunicação com a página via postMessage ───────────────────────────────────
// postMessage/addEventListener cruzam o boundary do isolated world sem CSP issues

// Sinaliza presença imediatamente
window.postMessage({ type: 'MC_EXTENSION_READY' }, '*')

// Escuta mensagens da página
window.addEventListener('message', e => {
  if (e.source !== window) return

  // Responde ao probe de detecção
  if (e.data?.type === 'MC_EXTENSION_PROBE') {
    window.postMessage({ type: 'MC_EXTENSION_READY' }, '*')
    return
  }

  // Página quer iniciar importação
  if (e.data?.type === 'MC_AVEC_IMPORT') {
    chrome.runtime.sendMessage({ action: 'startImport', ...e.data.detail })
  }
})

// ── Bridge para o background injetar arquivos ──────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'injectFile') {
    injectFile(msg)
      .then(() => sendResponse({ ok: true }))
      .catch(err => sendResponse({ ok: false, error: err.message }))
    return true
  }

  // Repassa status do background para a página
  if (msg.action === 'statusUpdate') {
    window.postMessage({ type: 'MC_AVEC_STATUS', detail: msg }, '*')
  }
})

async function injectFile({ key, data, filename, inicio, fim }) {
  await waitForBridge()
  const uint8 = new Uint8Array(data)
  const blob = new Blob([uint8], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
  const file = new File([blob], filename, { type: blob.type })
  await window.__mcImport(key, file, { inicio, fim })
}

function waitForBridge(timeout = 10_000) {
  return new Promise((resolve, reject) => {
    const deadline = Date.now() + timeout
    function check() {
      if (typeof window.__mcImport === 'function') return resolve()
      if (Date.now() > deadline) return reject(new Error('Bridge __mcImport não encontrado'))
      setTimeout(check, 200)
    }
    check()
  })
}
