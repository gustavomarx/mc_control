;(function () {
  'use strict'

  // Só ativa em abas abertas pelo mc_control (URL de envio com phone+text)
  const initialHref = location.href
  if (!initialHref.includes('web.whatsapp.com/send')) return

  // Só age no ENVIO AUTOMÁTICO: o mc_control abre essas abas com
  // window.open(url, 'wa-sender-tab'). Envios manuais (botões dos cards, CRM)
  // abrem com target _blank e não podem ser clicados nem fechados pela extensão.
  const AUTO_SEND_TAB_NAME = 'wa-sender-tab'
  if (window.name !== AUTO_SEND_TAB_NAME) return

  // ── Configurações ──────────────────────────────────────────────────────────
  const MAX_WAIT_MS        = 90_000  // timeout máximo aguardando WA carregar
  const INITIAL_DELAY_MS   =  3_000  // aguarda antes de começar a verificar
  const PRE_SEND_DELAY_MS  =  1_500  // buffer após botão pronto antes de clicar
  const POST_SEND_DELAY_MS =  3_000  // aguarda após envio para confirmar antes de fechar
  const SENT_CONFIRM_MS    =  5_000  // timeout máximo aguardando confirmação de envio

  // ── Estado ─────────────────────────────────────────────────────────────────
  const startedAt = Date.now()
  let done = false

  // ── Seletores do input do WA (fallback em cascata) ─────────────────────────
  const INPUT_SELECTORS = [
    'div[contenteditable="true"][data-tab="10"]',
    'div[contenteditable="true"][data-tab="6"]',
    'footer div[contenteditable="true"]',
    'div[contenteditable="true"][aria-label="Digite uma mensagem"]',
    'div[contenteditable="true"][aria-label="Type a message"]',
    'div[contenteditable="true"][aria-placeholder]',
  ]

  // ── Seletores do botão de envio ────────────────────────────────────────────
  const SEND_BTN_SELECTORS = [
    'button[data-tab="11"]',
    'button[aria-label="Enviar"]',
    'button[aria-label="Send"]',
    'footer button[data-testid="send"]',
    'span[data-icon="send"]',
  ]

  function findInput() {
    for (const sel of INPUT_SELECTORS) {
      const el = document.querySelector(sel)
      if (el) return el
    }
    const footer = document.querySelector('footer')
    if (footer) return footer.querySelector('[contenteditable="true"]')
    return null
  }

  function findSendButton() {
    for (const sel of SEND_BTN_SELECTORS) {
      const el = document.querySelector(sel)
      if (el) {
        // Se o seletor é um span (ícone), sobe para o botão pai
        const btn = el.closest('button') || el
        if (btn) return btn
      }
    }
    // Último recurso: botão dentro do footer que não seja microfone
    const footer = document.querySelector('footer')
    if (footer) {
      const btns = footer.querySelectorAll('button')
      for (const btn of btns) {
        const icon = btn.querySelector('span[data-icon]')
        if (icon && icon.getAttribute('data-icon') === 'send') return btn
      }
    }
    return null
  }

  function hasText(el) {
    return el && el.textContent.trim().length > 10
  }

  // Verifica se o input ficou vazio (confirma que o envio ocorreu)
  function isInputEmpty(el) {
    return el && el.textContent.trim().length === 0
  }

  // ── Finaliza: envia clicando no botão e aguarda confirmação ───────────────
  function finish() {
    if (done) return
    done = true

    const input = findInput()
    const sendBtn = findSendButton()

    if (input && hasText(input) && sendBtn) {
      setTimeout(() => {
        input.focus()
        sendBtn.click()

        // Aguarda o input esvaziar como confirmação de envio
        const confirmStart = Date.now()
        const waitConfirm = setInterval(() => {
          const currentInput = findInput()
          const elapsed = Date.now() - confirmStart

          if (isInputEmpty(currentInput) || elapsed >= SENT_CONFIRM_MS) {
            clearInterval(waitConfirm)
            setTimeout(() => {
              chrome.runtime.sendMessage({ type: 'WA_CLOSE_TAB' })
            }, POST_SEND_DELAY_MS)
          }
        }, 300)
      }, PRE_SEND_DELAY_MS)
    } else {
      // Timeout ou elementos não encontrados: fecha aba mesmo assim
      chrome.runtime.sendMessage({ type: 'WA_CLOSE_TAB' })
    }
  }

  // ── Condição de prontidão: input com texto E botão de envio visível ────────
  function isReady() {
    const input = findInput()
    const sendBtn = findSendButton()
    return hasText(input) && sendBtn !== null
  }

  // ── Polling ────────────────────────────────────────────────────────────────
  let pollTimer = null

  function poll() {
    if (done) return

    const elapsed = Date.now() - startedAt
    if (elapsed >= MAX_WAIT_MS) {
      finish()
      return
    }

    if (isReady()) {
      observer.disconnect()
      finish()
    } else {
      pollTimer = setTimeout(poll, 800)
    }
  }

  // ── MutationObserver (detecta mudanças no DOM mais rápido que polling) ─────
  const observer = new MutationObserver(() => {
    if (done) { observer.disconnect(); return }
    if (isReady()) {
      clearTimeout(pollTimer)
      observer.disconnect()
      finish()
    }
  })

  // ── Inicia após delay inicial ──────────────────────────────────────────────
  setTimeout(() => {
    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true, attributes: true })
    }
    poll()
  }, INITIAL_DELAY_MS)

})()
