;(function () {
  'use strict'

  // Só ativa em abas abertas pelo mc_control (URL de envio com phone+text)
  const initialHref = location.href
  if (!initialHref.includes('web.whatsapp.com/send')) return

  // ── Configurações ──────────────────────────────────────────────────────────
  const MAX_WAIT_MS      = 90_000  // timeout máximo aguardando WA carregar
  const INITIAL_DELAY_MS =  5_000  // aguarda 5s antes de começar a verificar
  const PRE_SEND_DELAY_MS =  2_000  // buffer após detectar texto antes de pressionar Enter
  const POST_SEND_DELAY_MS = 2_000  // aguarda 2s após Enter para garantir envio

  // ── Estado ─────────────────────────────────────────────────────────────────
  const startedAt = Date.now()
  let done = false

  // ── Seletores do input do WA (fallback em cascata) ─────────────────────────
  const SELECTORS = [
    'div[contenteditable="true"][data-tab="10"]',
    'div[contenteditable="true"][data-tab="6"]',
    'footer div[contenteditable="true"]',
    'div[contenteditable="true"][aria-label="Digite uma mensagem"]',
    'div[contenteditable="true"][aria-label="Type a message"]',
    'div[contenteditable="true"][aria-placeholder]',
  ]

  function findInput() {
    for (const sel of SELECTORS) {
      const el = document.querySelector(sel)
      if (el) return el
    }
    // último recurso: contenteditable dentro do footer
    const footer = document.querySelector('footer')
    if (footer) return footer.querySelector('[contenteditable="true"]')
    return null
  }

  function hasText(el) {
    return el && el.textContent.trim().length > 10
  }

  // ── Simulação de tecla Enter ───────────────────────────────────────────────
  function pressEnter(el) {
    el.focus()

    const opts = {
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      which: 13,
      bubbles: true,
      cancelable: true,
    }

    ;['keydown', 'keypress', 'keyup'].forEach(type => {
      el.dispatchEvent(new KeyboardEvent(type, opts))
    })
  }

  // ── Finaliza: envia e fecha a aba via background ───────────────────────────
  function finish() {
    if (done) return
    done = true

    const input = findInput()

    if (input && hasText(input)) {
      setTimeout(() => {
        pressEnter(input)
        setTimeout(() => {
          chrome.runtime.sendMessage({ type: 'WA_CLOSE_TAB' })
        }, POST_SEND_DELAY_MS)
      }, PRE_SEND_DELAY_MS)
    } else {
      // Timeout ou input não encontrado: fecha aba mesmo assim
      chrome.runtime.sendMessage({ type: 'WA_CLOSE_TAB' })
    }
  }

  // ── Polling ────────────────────────────────────────────────────────────────
  let pollTimer = null

  function poll() {
    if (done) return

    const elapsed = Date.now() - startedAt
    if (elapsed >= MAX_WAIT_MS) {
      finish()
      return
    }

    const input = findInput()
    if (input && hasText(input)) {
      observer.disconnect()
      finish()
    } else {
      pollTimer = setTimeout(poll, 1000)
    }
  }

  // ── MutationObserver (complemento ao polling para detectar mais rápido) ───
  const observer = new MutationObserver(() => {
    if (done) { observer.disconnect(); return }
    const input = findInput()
    if (input && hasText(input)) {
      clearTimeout(pollTimer)
      observer.disconnect()
      finish()
    }
  })

  // ── Inicia após delay inicial ──────────────────────────────────────────────
  setTimeout(() => {
    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true })
    }
    poll()
  }, INITIAL_DELAY_MS)

})()
